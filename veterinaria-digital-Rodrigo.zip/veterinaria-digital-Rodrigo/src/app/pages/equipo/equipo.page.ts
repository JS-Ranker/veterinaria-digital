import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-equipo',
  templateUrl: './equipo.page.html',
  styleUrls: ['./equipo.page.scss'],
  standalone: false
})
export class EquipoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
