import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citas',
  templateUrl: './citas.page.html',
  styleUrls: ['./citas.page.scss'],
  standalone: false
})
export class CitasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
